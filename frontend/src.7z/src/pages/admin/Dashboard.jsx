import { useAuth } from '../../context/AuthContext';
import { useNavigate } from 'react-router-dom';

function Dashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 py-6 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              Panel de Administración 👨‍💼
            </h1>
            <p className="text-gray-600 mt-1">Bienvenido, {user?.nombre}</p>
          </div>
          <button
            onClick={handleLogout}
            className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition"
          >
            Cerrar Sesión
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Estadísticas rápidas */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          {/* Card Usuarios */}
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Usuarios</p>
                <p className="text-2xl font-bold text-gray-900">--</p>
              </div>
              <div className="text-blue-500 text-4xl">👥</div>
            </div>
          </div>

          {/* Card Abonos */}
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Abonos Activos</p>
                <p className="text-2xl font-bold text-gray-900">--</p>
              </div>
              <div className="text-green-500 text-4xl">💳</div>
            </div>
          </div>

          {/* Card Escaneos Hoy */}
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Accesos Hoy</p>
                <p className="text-2xl font-bold text-gray-900">--</p>
              </div>
              <div className="text-purple-500 text-4xl">📱</div>
            </div>
          </div>

          {/* Card Pruebas Salud */}
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Pruebas Vigentes</p>
                <p className="text-2xl font-bold text-gray-900">--</p>
              </div>
              <div className="text-red-500 text-4xl">🏥</div>
            </div>
          </div>
        </div>

        {/* Acciones rápidas */}
        <div className="bg-white rounded-lg shadow p-6 mb-8">
          <h2 className="text-xl font-semibold mb-4">Acciones Rápidas</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <button
              onClick={() => navigate('/admin/usuarios')}
              className="px-6 py-4 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition text-left"
            >
              <div className="text-2xl mb-2">👥</div>
              <div className="font-semibold">Gestionar Usuarios</div>
              <div className="text-sm opacity-90">Ver y editar usuarios</div>
            </button>

            <button
              onClick={() => alert('Próximamente: Escanear QR')}
              className="px-6 py-4 bg-green-500 text-white rounded-lg hover:bg-green-600 transition text-left"
            >
              <div className="text-2xl mb-2">📱</div>
              <div className="font-semibold">Escanear QR</div>
              <div className="text-sm opacity-90">Control de acceso</div>
            </button>

            <button
              onClick={() => alert('Próximamente: Gestionar Abonos')}
              className="px-6 py-4 bg-purple-500 text-white rounded-lg hover:bg-purple-600 transition text-left"
            >
              <div className="text-2xl mb-2">💳</div>
              <div className="font-semibold">Gestionar Abonos</div>
              <div className="text-sm opacity-90">Ver y crear abonos</div>
            </button>
          </div>
        </div>

        {/* Mensaje temporal */}
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-6 text-center">
          <p className="text-blue-800 font-semibold">
            🚧 Dashboard en construcción
          </p>
          <p className="text-blue-600 mt-2">
            Las estadísticas y funcionalidades completas se agregarán próximamente
          </p>
        </div>
      </main>
    </div>
  );
}

export default Dashboard;