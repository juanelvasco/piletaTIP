import { useAuth } from '../../context/AuthContext';
import { useNavigate } from 'react-router-dom';

function Dashboard() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow">
        <div className="max-w-7xl mx-auto px-4 py-6 flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">
              Bienvenido, {user?.nombre}! 🏊
            </h1>
            <p className="text-gray-600 mt-1">Panel de Usuario</p>
          </div>
          <button
            onClick={handleLogout}
            className="px-4 py-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition"
          >
            Cerrar Sesión
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Información del usuario */}
        <div className="bg-white rounded-lg shadow p-6 mb-6">
          <h2 className="text-xl font-semibold mb-4">Mis Datos</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-gray-600">Nombre Completo</p>
              <p className="font-semibold">{user?.nombre} {user?.apellido}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Email</p>
              <p className="font-semibold">{user?.email}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">DNI</p>
              <p className="font-semibold">{user?.dni}</p>
            </div>
            <div>
              <p className="text-sm text-gray-600">Teléfono</p>
              <p className="font-semibold">{user?.telefono || 'No especificado'}</p>
            </div>
          </div>
        </div>

        {/* Cards de información */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Card Abono */}
          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-blue-500 text-3xl mb-2">💳</div>
            <h3 className="text-lg font-semibold mb-2">Mi Abono</h3>
            <p className="text-gray-600 text-sm">
              {user?.abonoActual ? 'Activo' : 'Sin abono'}
            </p>
            <button className="mt-4 w-full px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition">
              Ver Detalles
            </button>
          </div>

          {/* Card QR */}
          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-green-500 text-3xl mb-2">📱</div>
            <h3 className="text-lg font-semibold mb-2">Mi Código QR</h3>
            <p className="text-gray-600 text-sm">
              {user?.qrCode ? 'Disponible' : 'No generado'}
            </p>
            <button className="mt-4 w-full px-4 py-2 bg-green-500 text-white rounded hover:bg-green-600 transition">
              Ver QR
            </button>
          </div>

          {/* Card Salud */}
          <div className="bg-white rounded-lg shadow p-6">
            <div className="text-purple-500 text-3xl mb-2">🏥</div>
            <h3 className="text-lg font-semibold mb-2">Prueba de Salud</h3>
            <p className="text-gray-600 text-sm">
              {user?.pruebaSalud ? 'Vigente' : 'Sin registrar'}
            </p>
            <button className="mt-4 w-full px-4 py-2 bg-purple-500 text-white rounded hover:bg-purple-600 transition">
              Ver Estado
            </button>
          </div>
        </div>

        {/* Mensaje temporal */}
        <div className="mt-8 bg-blue-50 border border-blue-200 rounded-lg p-6 text-center">
          <p className="text-blue-800 font-semibold">
            🚧 Dashboard en construcción
          </p>
          <p className="text-blue-600 mt-2">
            Las funcionalidades completas se agregarán próximamente
          </p>
        </div>
      </main>
    </div>
  );
}

export default Dashboard;